const readlineSync = require('readline-sync');
const fs = require('fs');
const bcrypt = require('bcryptjs');

// Register user
function registerUser() {
    const name = readlineSync.question('Enter your name: ');
    const email = readlineSync.question('Enter your email: ');
    const password = readlineSync.question('Enter your password: ', { hideEchoBack: true });

    // Encrypt password
    const hashedPassword = bcrypt.hashSync(password, 10);

    // Create user object
    const newUser = {
        name,
        email,
        password: hashedPassword
    };

    // Read existing users from file
    let users = [];
    if (fs.existsSync('users.json')) {
        users = JSON.parse(fs.readFileSync('users.json'));
    }

    // Add the new user to the users array
    users.push(newUser);

    // Save the updated users array to the file
    fs.writeFileSync('users.json', JSON.stringify(users, null, 2));

    console.log('Registration successful!');
}

// User login
function loginUser() {
    const email = readlineSync.question('Enter your email: ');
    const password = readlineSync.question('Enter your password: ', { hideEchoBack: true });

    // Read users from the file
    if (fs.existsSync('users.json')) {
        const users = JSON.parse(fs.readFileSync('users.json'));

        // Find the user by email
        const user = users.find(u => u.email === email);

        if (user && bcrypt.compareSync(password, user.password)) {
            console.log('Login successful!');
            userMenu();
        } else {
            console.log('Invalid email or password.');
        }
    } else {
        console.log('No users found.');
    }
}

// User menu after login
function userMenu() {
    console.log('Welcome to the User Menu!');
    console.log('1. View Profile');
    console.log('2. Logout');
    console.log('3. Exit');

    const choice = readlineSync.question('Choose an option: ');

    switch (choice) {
        case '1':
            viewProfile();
            break;
        case '2':
            logout();
            break;
        case '3':
            process.exit();
            break;
        default:
            console.log('Invalid option. Try again.');
            userMenu();
    }
}

// View Profile
function viewProfile() {
    console.log('Displaying user profile...');
    // You can display user details here
    userMenu();
}

// Logout
function logout() {
    console.log('Logging out...');
    loginUser();
}

// Starting the application
function startApp() {
    const action = readlineSync.question('Enter 1 to register or 2 to login: ');

    if (action === '1') {
        registerUser();
    } else if (action === '2') {
        loginUser();
    } else {
        console.log('Invalid choice. Exiting.');
        process.exit();
    }
}

startApp();
